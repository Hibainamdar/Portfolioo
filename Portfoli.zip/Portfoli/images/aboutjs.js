function showMessage() {
    alert("Thanks for using this service");
}   